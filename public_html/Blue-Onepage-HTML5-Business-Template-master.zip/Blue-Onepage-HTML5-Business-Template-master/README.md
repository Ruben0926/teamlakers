Blue OnePage HTML5 Business Template
========
<img src="https://cloud.githubusercontent.com/assets/10640964/5987921/7650444a-a970-11e4-91e4-6f53baebca99.jpg" />

<a href="http://themefisher.com/download/blue-one-page-business-template/">Live Preview</a>
========
Blue is a html5 one page landing page template developed based on twitter bootstrap 3.2. It can be used as show case for your Business website and Beauty &amp; Spa website.We organized file structure and descriptive comments on codes will enable your showcase easy to maintain.
